from django.db import models
import os

from django.contrib.auth.models import User

# Create your models here.
#class CustomerLogin(models.Model):

Category_choices=(
    ("Bags","Bags"),
    ("Shoes","Shoes"),
    ("Men","Men"),
    ("Women","Women"),
    
)


STATUS_CHOICES=(
    ("Pending","Pending"),
    ("Shipped","Shipped"),
    ("Delivered","Delivered"),
    ("Cancelled","Cancelled"),

)

'''class Categories(models.Model):
    class Meta:
        
        verbose_name_plural = 'Categories'
    cat_id=models.IntegerField()
    cat_name=models.CharField(max_length=300)
    
    date = models.DateTimeField(auto_now_add=True, blank=True)

    def __str__(self):
        return f"{self.cat_id} {self.cat_name} {self.date}"
'''
class Customers(models.Model):
    class Meta:
        
        verbose_name_plural = 'Customers'
    user=models.OneToOneField(User, on_delete=models.CASCADE)
    address=models.TextField()
    phone=models.CharField(max_length=15)
    city=models.CharField(max_length=100)
    postal=models.CharField(max_length=10)

    def __str__(self):
        return f"{self.user.username} {self.address} {self.phone} {self.city} {self.postal}  "

class Products(models.Model):
    class Meta:
        
        verbose_name_plural = 'Products'
    product_id=models.IntegerField()
    product_name=models.CharField(max_length=300)
    category_id=models.CharField(max_length=20,choices=Category_choices)
    product_image=models.FileField(upload_to="uploads/")
    product_price=models.FloatField(default=0)
    product_stock=models.PositiveIntegerField(default=0)
    product_date=models.DateTimeField(auto_now_add=True, blank=True)

    def upload_path(self,filename):
        return os.path.join(self.category_id.cat_name,filename)

    def __str__(self):
        return f"{self.product_id} {self.product_name} {self.category_id} {self.product_price} {self.product_image} {self.product_date} "


class Cart(models.Model):
    customer = models.OneToOneField(Customers, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Cart of {self.customer.user.username}"

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Products, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def subtotal(self):
        return self.product.product_price * self.quantity

    def __str__(self):
        return f"{self.quantity} x {self.product.product_name}"

class Orders(models.Model):
    class Meta:
        verbose_name_plural="Orders"

    order_id=models.IntegerField()
    order_date=models.DateField()
    customer=models.ForeignKey(Customers, on_delete=models.CASCADE)
    total_price=models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Pending')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.id}  {self.customer.user.username} {self.order_date} {self.total_price} {self.status}"

class OrderItem(models.Model):
    order = models.ForeignKey(Orders, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Products, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.quantity} x {self.product.product_name} in Order {self.order.id}"

class Payment(models.Model):
    order = models.OneToOneField(Orders, on_delete=models.CASCADE)
    payment_id = models.CharField(max_length=100, unique=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    is_successful = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Payment {self.payment_id} for Order {self.order.id}"

