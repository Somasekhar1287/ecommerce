from django.urls import path,include
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings
from django.conf.urls.static import static
app_name="store"
urlpatterns = [
   
    path("",views.index,name="index"),
    path("checkout",views.checkout,name="checkout"),
    path("products",views.products,name="products"),
    path("login_view",views.login_view,name="login_view"),
    path("get_product",views.get_product,name="get_product"),
    path("add_cart",views.add_cart,name="add_cart"),
    path("my_orders",views.my_orders,name="my_orders"),

    path("add_order",views.add_order,name="add_order"),
    path("success",views.success,name="success"),
    path("logout",views.log_out,name="log_out"),
    path("register",views.register,name="register")
]
urlpatterns+=staticfiles_urlpatterns()
urlpatterns+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)