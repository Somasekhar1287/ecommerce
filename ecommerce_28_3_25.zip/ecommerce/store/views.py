from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import logout
from django.contrib.auth import authenticate, login
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse,HttpResponse
from .models import Products,Cart,CartItem,Customers,Orders,OrderItem
from django.apps import apps
from .forms import RegisterForm
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm
import json
import random
from datetime import datetime


# Create your views here.
def index(request):
    latest_prod_ids=[]
    products=Products.objects.all()
    latest_products=Products.objects.all().order_by('-product_date')[:2].values()

    for latest_product in latest_products:
        latest_prod_ids.append(latest_product["product_id"])
        print(latest_product)


    if "is_customer_logged" in request.session:
        is_customer_logged=request.session["is_customer_logged"]
    else:
        is_customer_logged=False

    if "username" in request.session:
        username=request.session["username"]
    else:
        username=""
    context={
        'products':products,
        "latest_prod_ids":latest_prod_ids,
        "latest_products":latest_products,
        "is_logged":is_customer_logged,
        "username":username
    }
    print(latest_products)
    return render(request,"store/index.html",context)



def products(request):
    if "is_customer_logged" in request.session:
        is_customer_logged=request.session["is_customer_logged"]
    else:
        is_customer_logged=False

    if "username" in request.session:
        username=request.session["username"]
    else:
        username=""
    products=Products.objects.all()
    print(products)
    context={
        'products':products,
        "is_logged":is_customer_logged,
        "username":username
    }
    return render(request,"store/products.html",context)


def login_view(request):
    if request.method=="POST":
        form=AuthenticationForm(data=request.POST)
        print(request.POST["username"])
        try:
            user = User.objects.get(username=request.POST["username"])
        except User.DoesNotExist:
    # Handle the case where the user does not exist
            print("User not found")
            form=AuthenticationForm()
            return render(request,"store/login.html",{"form":form, "msg":"Username doesnot exist"})
        else:
    # Check if the user is active
            if user.is_active:
                if form.is_valid():
                    request.session["is_customer_logged"]=True
                    request.session["username"]=form.cleaned_data["username"]
                    user = authenticate(request, username=form.cleaned_data["username"], password=form.cleaned_data["password"])
                    login(request,user)
                    return redirect("store:index")
                print("User is active")
            else:
                print("User is not active")
                form=AuthenticationForm()
                return render(request,"store/login.html",{"form":form, "msg":"Admin approval Pending"})  
            

    else:
        form=AuthenticationForm()
        return render(request,"store/login.html",{"form":form})

def log_out(request):
    logout(request)
    return redirect("store:login_view")

def register(request):
    if request.method=="POST":
        form=RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("store:login_view")
    else:
        form = RegisterForm()
        return render(request,"store/register.html",{"form":form})

def get_product(request):
    if request.method=="POST":
        prod_id=request.POST["product_id"]
        if Products.objects.all().exists():
            product=Products.objects.filter(product_id=prod_id).values_list('product_name', 'product_image','product_price').get()
            print(product)
            #product_dict={prod_id:list(product)}
            #request.session["items"]=product_dict
            return JsonResponse({"product":list(product)})
        else:
            pass
    else:
        context={
            'error':"You are not allowed"
        }
        return render(request,"store/msg.html",context)

def checkout(request):
    if "is_customer_logged" in request.session:
        username=request.user
        customer=Customers.objects.filter(user=request.user).all()
        print(User.objects.values_list('id').get(username=username))
        context={
            "username":username,
            "email":request.user.email,
            "customer":customer
        }
   
        return render(request,"store/checkout.html",context)
    else:
        return redirect("store:login_view")

def add_cart(request):
    if request.method=="POST":
        cart_products=request.POST["cart_products"]
        print(cart_products)
        print(request.user)
        print(type(json.loads(cart_products)))
        cart_dict=json.loads(cart_products)
        print(cart_dict)
        for key,value in cart_dict.items():
            product_id=key
            product=get_object_or_404(Products,product_id=product_id)
            print(product)
            customer=request.user.customers
            cart,created=Cart.objects.get_or_create(customer=customer)
            

            cart_item,created=CartItem.objects.get_or_create(cart=cart,product=product)
            if not created:
                cart_item.quantity+=1
            cart_item.save()
        return HttpResponse("Success")
        
    else:
        context={
            'error':"You are not allowed"
        }
        return render(request,"store/msg.html",context)


def add_order(request):
    if request.method=="POST":
        user_id=User.objects.get(username=request.user)
        customer=Customers.objects.get(user=user_id)
        cart=Cart.objects.get(customer=customer)
        order_id=random.randrange(1, 10000)

        order=Orders.objects.create(
            order_id=order_id,
            order_date=datetime.today().strftime('%Y-%m-%d'),
            customer=customer,
            total_price=sum(item.subtotal() for item in cart.items.all()),
            status="Pending"
        )
        for item in cart.items.all():
            OrderItem.objects.create(order=order, product=item.product, quantity=item.quantity, price=item.product.product_price)

        cart.items.all().delete() 
        return HttpResponse("Success")
        
    else:
        context={
            'error':"You are not allowed"
        }
        return render(request,"store/msg.html",context)

def user_details(request):
    if request.method=="POST":
        pass
    else:
        return render(request,"store/my_profile.html")

def my_orders(request):
    if Customers.objects.filter(user=request.user).exists():
        orders=Orders.objects.filter(customer=request.user.customers).all()
    else:
        orders=None
    context={
        "orders":orders
    }
    return render(request,"store/my_orders.html",context)

@csrf_exempt
def success(request):
    return render(request, 'store/success.html')



'''





if Products.objects.all().exists():
            product=Products.objects.filter(product_id=prod_id).values_list('product_name', 'product_image','product_price').get()
            print(product)
            #product_dict={prod_id:list(product)}
            #request.session["items"]=product_dict
            return JsonResponse({"product":list(product)})
        else:
            pass
'''