from django.contrib import admin
from .models import Products,Orders,OrderItem,Customers,Payment,Cart,CartItem
from django.utils.html import format_html
# Register your models here.

'''
from .models import Categories
class categoryAdmin(admin.ModelAdmin):
    list_display=("cat_id","cat_name","date")
'''
class ProductsAdmin(admin.ModelAdmin):
    
    def image(self, obj):  # receives the instance as an argument
        return format_html('<img src="{}" style="max-width:50px; max-height:50px"/>'.format(obj.product_image.url))
    
    list_display=["product_id","product_name","category_id","image","product_stock","product_price","product_date"]

class CustomersAdmin(admin.ModelAdmin):
    list_display=["user","address","phone","city","postal"]

class CartAdmin(admin.ModelAdmin):
    list_display=["customer","created_at"]

class CartItemAdmin(admin.ModelAdmin):
    list_display=["cart","product","quantity"]

class OrdersAdmin(admin.ModelAdmin):
    list_display=["order_id","customer","total_price","status","created_at","order_date"]
   
class OrderItemAdmin(admin.ModelAdmin):
    list_display=["order","product","quantity","price"]

class PaymentAdmin(admin.ModelAdmin):
    list_display=["order","payment_id","amount","is_successful","created_at"]



#admin.site.register(Categories,categoryAdmin)
admin.site.register(Products,ProductsAdmin)
admin.site.register(Customers,CustomersAdmin)
admin.site.register(Orders,OrdersAdmin)
admin.site.register(OrderItem,OrderItemAdmin)
admin.site.register(Payment,PaymentAdmin)
admin.site.register(Cart,CartAdmin)
admin.site.register(CartItem,CartItemAdmin)