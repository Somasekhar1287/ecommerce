console.log("hello");
var categories=document.getElementsByClassName("down-angle");

for(var i=0;i<categories.length;i++){
    categories[i].addEventListener("click",function(){
        var elem=this;
        console.log(elem.classList);
        if(this.classList.contains("fa-angle-right")){
            elem.classList.remove("fa-angle-right");
            elem.classList.add("fa-angle-down");

        }
        else if(this.classList.contains("fa-angle-down")){
            elem.classList.remove("fa-angle-down");
            elem.classList.add("fa-angle-right");

        }
        var cat_attr=this.getAttribute("data-cat");
        console.log(cat_attr);
        
        document.getElementsByClassName(cat_attr)[0].style.display=document.getElementsByClassName(cat_attr)[0].style.display==="none" ? "block" :"none";
    });
}