
document.getElementById("shop-bag").addEventListener("click",function(){
    console.log("cart clicked");
    document.getElementById("cart-block").style.width="25%";
    document.getElementsByClassName("ecommerce-container")[0].style.width="75%";
});

document.getElementById("cart-close").addEventListener("click",function(){
    document.getElementById("cart-block").style.width="0%";
    document.getElementsByClassName("ecommerce-container")[0].style.width="100%";
});














  
/*


var items=[
    {
        1:{
    "item_name":"Item1",
    "item_image":"/static/store/media/bags/vintage-leather-canvas-messenger-bag-brown-travel-bag.png",
    "item_price":"800",},
    2:{
"item_name":"Item2",
    "item_image":"/static/store/media/shirts/mens-black-white-plaid-long-sleeve-shirt-fashion-apparel.png",
    "item_price":"800",
    }
}
];

console.log(items[0][1].item_image);
var cart_btns=document.getElementsByClassName("cart-btn");




function addToCart(){
    var item_id=this.getAttribute("data-id");
    document.getElementById("cart-items-block").innerHTML+=`<div class="cart-item">
                        <div class="item">
                            <img class="item-image" src="`+items[0][item_id].item_image+`" />
                            <div class="item_details">
                                <h4 class="item_name">`+items[0][item_id].item_name+`</h4>
                                <p>Price: &#8377;<span class="item_price"> `+items[0][item_id].item_price+`</span></p>
                            </div>
                            <div class="item_quantity">
                                <input type="number" id="qty" class="qty" value="1" />
                            </div>
                            <div class="item_subtotal">
                                <p>&#8377; <span class="subtot">`+items[0][item_id].item_price+`</span></p>
                            </div>
                        </div>
                    </div>`;

}
for(var i=0;i<cart_btns.length;i++){
    cart_btns[i].addEventListener("click",addToCart);
}














var elements=document.getElementsByClassName("cart-btn");
var qty=1;
function addQuantity(){
    var id=this.parentElement.nextSibling.getAttribute("id");
    var item_id=this.getAttribute("data-id");
    document.getElementById(id).innerHTML="<button data-id='"+item_id+"' class='button_remove'>-</button> <input type='text' data-id='"+item_id+"' class='qty_class' value='"+qty+"' /><button type='button' data-id='"+item_id+"' class='button_add'>+</button>";
    console.log(this.getAttribute("data-id"));
}


for(var i=0;i<elements.length;i++){
    elements[i].addEventListener("click",addQuantity);
}

var add_btn_items=document.getElementsByClassName("button_add");

function changeQuantity(){
    console.log("btn_added");
    var item_qty=this.nextSibling;
    console.log(item_qty);
}


for(var i=0;i<add_btn_items.length;i++){
    add_btn_items[i].addEventListener("click",changeQuantity);
}
    */