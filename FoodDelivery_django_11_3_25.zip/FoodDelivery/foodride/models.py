from django.db import models
from django.contrib.auth.models import User

dish_choices=(
    ("Veg","Veg"),
    ("Non-Veg","Non-Veg"),
)

FOOD_STATUS=(
    ("available","Available"),
    ("not available","Not Available"),
)
STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Accepted', 'Accepted'),
        ('Out for Delivery', 'Out for Delivery'),
        ('Delivered', 'Delivered'),
        ('Cancelled', 'Cancelled'),
    ]
# Create your models here.
class category(models.Model):
    class Meta:
        
        verbose_name_plural = 'Categories'
    category_name=models.CharField(max_length=300)
    category_image=models.FileField(upload_to="uploads/")
    category_desc=models.TextField()

    def __str__(self):
        return f"{self.category_name} {self.category_image} {self.category_desc}"


class Restaurant(models.Model):
    name=models.CharField(max_length=300)
    address=models.TextField()
    latitude=models.FloatField()
    longitude=models.FloatField()
    contact=models.CharField(max_length=20)
    image=models.FileField(upload_to="uploads/restaurants/")

    def __str__(self):
        return f"{self.name} {self.address} {self.latitude} {self.longitude} {self.contact} {self.image}"


class foodItem(models.Model):
    name=models.CharField(max_length=300)
    item_image=models.FileField(upload_to="uploads/items/")
    price=models.FloatField()
    description=models.TextField()
    restaurant=models.ForeignKey(Restaurant,on_delete=models.CASCADE)
    food_category=models.ForeignKey(category,on_delete=models.CASCADE)
    item_status=models.CharField(max_length=30,choices=FOOD_STATUS,default="available")
    item_type=models.CharField(choices=dish_choices,max_length=10)


    def __str__(self):
        return f"{self.name} {self.item_image} {self.price} {self.description} {self.restaurant.name} {self.item_type} {self.item_status}"


class customer(models.Model):
    user=models.OneToOneField(User, on_delete=models.CASCADE,limit_choices_to={'is_staff': False,'is_superuser': False})
    address=models.TextField()
    phone=models.CharField(max_length=20)
    location=models.CharField(max_length=200,default=None)
    latitude=models.FloatField()
    longitude=models.FloatField()

    def __str__(self):
        return f"{self.user} {self.address} {self.phone} {self.latitude} {self.longitude} "

class deliveryPartner(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    phone=models.CharField(max_length=15)
    vehicle_number=models.CharField(max_length=30)
    

    def __str__(self):
        return f"{self.user}  {self.phone} {self.vehicle_number} "

class Cart(models.Model):
    customer = models.OneToOneField(customer, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Cart of {self.customer.user.username}"

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(foodItem, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def subtotal(self):
        return self.product.price * self.quantity

    def __str__(self):
        return f"{self.quantity} x {self.product.name}"

class order(models.Model):
    order_id=models.IntegerField(default=0)
    order_date=models.DateField(default=None)
    customer=models.ForeignKey(customer,on_delete=models.CASCADE)
    restaurant=models.ForeignKey(Restaurant,on_delete=models.CASCADE)
    food_items = models.ManyToManyField(foodItem, through='OrderItem')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    total_price = models.FloatField()
    order_time = models.DateTimeField(auto_now_add=True)
    delivery_partner=models.ForeignKey(deliveryPartner, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f" {self.id} {self.order_id} {self.customer} {self.status} {self.total_price} {self.order_time} {self.customer.user.username} {self.restaurant} {self.restaurant.name}"


class orderItem(models.Model):
    order=models.ForeignKey(order,on_delete=models.CASCADE)
    food_item=models.ForeignKey(foodItem,on_delete=models.CASCADE)
    quantity=models.PositiveIntegerField(default=1)
    price = models.FloatField(default=0.0)

    def __str__(self):
        return f"{self.order.order_id} {self.order} {self.food_item.name} {self.food_item} {self.quantity}"



