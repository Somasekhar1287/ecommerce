from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse,JsonResponse
from .models import category,foodItem,Restaurant,customer,Cart,CartItem,order,orderItem
from django.contrib.auth import logout
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm
from .forms import RegisterForm,customerForm
from . import get_route
import json
import folium
import random
from datetime import datetime
# Create your views here.


# authenitication
def register_view(request):
    if request.method=="POST":
        form=RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("foodride:login_view")
    else:
        form = RegisterForm()
        return render(request,"foodride/register.html",{"form":form})


        
def login_view(request):
    if request.method=="POST":
        form=AuthenticationForm(data=request.POST)
        print(request.POST["username"])
        try:
            user = User.objects.get(username=request.POST["username"])
        except User.DoesNotExist:
    # Handle the case where the user does not exist
            print("User not found")
            form=AuthenticationForm()
            return render(request,"foodride/login.html",{"form":form, "msg":"Username doesnot exist"})
        else:
    # Check if the user is active
            if user.is_active:
                if form.is_valid():
                    request.session["is_customer_logged"]=True
                    request.session["username"]=form.cleaned_data["username"]
                    user = authenticate(request, username=form.cleaned_data["username"], password=form.cleaned_data["password"])
                    if user is not None:
                        login(request,user)
                        print(f"Authentication success {user}")
                    else:
                        print(f"Authentication failed to {user}")
                    return redirect("foodride:index")
                print("User is active")
            else:
                print("User is not active")
                form=AuthenticationForm()
                return render(request,"foodride/login.html",{"form":form, "msg":"Admin approval Pending"})  
            

    else:
        form=AuthenticationForm()
        return render(request,"foodride/login.html",{"form":form})

def log_out(request):
    logout(request)
    return redirect("foodride:login_view")





def index(request):
    if "is_customer_logged" in request.session:
        is_customer_logged=request.session["is_customer_logged"]
    else:
        is_customer_logged=None
    
    categories=category.objects.all()
    print(is_customer_logged)
    context={
        "categories":categories,
        "username":request.user,
        "is_customer_logged":is_customer_logged
    }
    return render(request,"foodride/index.html",context)

def show_category_restaurants(request,cat_name):
    if "is_customer_logged" in request.session:
        is_customer_logged=request.session["is_customer_logged"]
    else:
        is_customer_logged=None
    
    restaurants=foodItem.objects.filter(food_category__category_name=cat_name).values('restaurant').distinct()
    
    print(restaurants)
    restaurant_list=[]

    for restaurant in restaurants:
        print(Restaurant.objects.all().filter(id=restaurant["restaurant"]))
        restaurant_list.append(Restaurant.objects.all().filter(id=restaurant["restaurant"]))

    context={
        "restaurant_list":restaurant_list,
        "username":request.user,
        "is_customer_logged":is_customer_logged,
        "cat_name":cat_name
    }
    return render(request,"foodride/category_restaurants.html",context)


def show_restaurant_category_items(request,cat_name,restaurant):
    if "is_customer_logged" in request.session:
        is_customer_logged=request.session["is_customer_logged"]
    else:
        is_customer_logged=None
    
    items=foodItem.objects.all().filter(food_category__category_name=cat_name,restaurant__id=restaurant)
    print(foodItem.objects.filter(id=1).all())
    print(is_customer_logged)
    context={
        
        "items":items,
        "cat_name":cat_name,
        "username":request.user,
        "is_customer_logged":is_customer_logged,
        "restaurant":restaurant,
    }
    return render(request,"foodride/restaurant_items.html",context)


def get_items(request):
    if request.method=="POST":
        item_id=request.POST["item_id"]
        print(item_id)
        if foodItem.objects.all().exists():
            print(foodItem.objects.all())
            item=foodItem.objects.filter(id=item_id).all().values()
            print(item)
            return JsonResponse({"item":list(item)})
        else:
            pass



def add_cart(request):
    if "is_customer_logged" in request.session:
        if request.method=="POST":
            cart_items=request.POST["cart_items"]
            cart_items_dict=json.loads(cart_items)
            print(cart_items_dict)
            for key,value in cart_items_dict.items():
                item_id=key
                item=get_object_or_404(foodItem,id=item_id)
                cart,created=Cart.objects.get_or_create(customer=request.user.customer)
                cart_item,created=CartItem.objects.get_or_create(cart=cart,product=item)
                if not created:
                    cart_item.quantity+=1
                cart_item.save()

            return HttpResponse("success")
    else:

        return HttpResponse("unauthorized")

def add_order(request):
    if request.method=="POST":
        
        cart=Cart.objects.get(customer=request.user.customer)
        print(cart.items)
        cartitem=CartItem.objects.get(cart=cart)
        order_id=random.randrange(1, 10000)

        Order=order.objects.create(
            order_id=order_id,
            order_date=datetime.today().strftime('%Y-%m-%d'),
            restaurant=cartitem.product.restaurant,
            customer=request.user.customer,
            total_price=sum(item.subtotal() for item in cart.items.all()),
            status="Pending"
        )
        for item in cart.items.all():
            orderItem.objects.create(order=Order, food_item=item.product, quantity=item.quantity, price=item.product.price)

        cart.items.all().delete()
        return HttpResponse("success")
        
    else:
        context={
            'error':"You are not allowed"
        }
        return render(request,"store/msg.html",context)

def checkout(request):
    if "is_customer_logged" in request.session and "username" in request.session:
        log_user=request.session["username"]
        user_id=User.objects.values_list('id').get(username=log_user)
        cust=customer.objects.filter(user=user_id).all()
        print(User.objects.values_list('id').get(username=log_user))
        figure = folium.Figure()
        customer_details=customer.objects.all()
        m = folium.Map(location=[16.7152607,81.0823865],width="100%",height="400px",
                    zoom_start=15)
        m.add_to(figure)
        for customer_detail in customer_details:
            folium.Marker(location=[customer_detail.latitude,customer_detail.longitude],icon=folium.Icon(color="orange",icon="home", prefix='fa',icon_color='darkpurple')).add_to(m)
        figure.render()
        context={
            "username":log_user,
            'map':figure,
            "customer":cust
        }
   
        return render(request,"foodride/checkout.html",context)
    else:
        return redirect("foodride:login_view")






def customer_details(request):
    if "is_customer_logged" in request.session and "username" in request.session:
        log_user=request.session["username"]
        user_id=User.objects.values_list('id').get(username=log_user)
        orders=order.objects.all().filter(customer=request.user.customer)
        print(orders)
        if customer.objects.filter(user=user_id).all().exists():
            figure = folium.Figure()
            customer_details=customer.objects.all()
            m = folium.Map(location=[16.7152607,81.0823865],width="50%",height="50%",
                       zoom_start=15)
            m.add_to(figure)
            for customer_detail in customer_details:
                folium.Marker(location=[customer_detail.latitude,customer_detail.longitude],icon=folium.Icon(color="orange",icon="home", prefix='fa',icon_color='darkpurple')).add_to(m)
            figure.render()
    
    
            context={
                "customer":customer_details,
                "orders":orders,
                'map':figure
            }
            return render(request,"foodride/customer.html",context)
        else:
            if request.method=="POST":
                form=customerForm(request.POST)
                if form.is_valid:
                    form.save()
                    return redirect("foodride:success")
            else:
                form=customerForm()
                context={
                    "form":form
                }
            return render(request,"foodride/customer.html",context)

def show_route(request,lat1,long1,lat2,long2):
    figure = folium.Figure()
    lat1,long1,lat2,long2=float(lat1),float(long1),float(lat2),float(long2)
    route=get_route.get_route(long1,lat1,long2,lat2)
    print(request.user.username)
    m = folium.Map(location=[(route['start_point'][0]),
                                 (route['start_point'][1])], 
                       zoom_start=18)
    m.add_to(figure)
    folium.PolyLine(route['route'],weight=8,color='blue',opacity=0.9).add_to(m)
    print(route["distance"])
    print(route["distance"])
    folium.Marker(location=route['start_point'],icon=folium.Icon(icon='play', color='green')).add_to(m)
    folium.Marker(location=route['end_point'],icon=folium.Icon(icon='stop', color='red')).add_to(m)
    figure.render()
    
    context={'map':figure}
    
    return render(request,'foodride/show_route.html',context)


def success(request):
    return render(request,"foodride/success.html")
