from django.contrib import admin
from .models import passengars,riders,ride,locations,ridePrice

# Register your models here.
class rideAdmin(admin.ModelAdmin):
    list_display=["passengar","driver","destination_lat","destination_lng","ride_choice","fare","status","created_on"]

class passengarAdmin(admin.ModelAdmin):
     list_display=["passengar","phone","email","created_on"]


class riderAdmin(admin.ModelAdmin):
     list_display=["rider","phone","vehicle_type","registration_number"]


class locationAdmin(admin.ModelAdmin):
    list_display=["passengar","location_name","location_lat","location_lng"]

class ridePriceAdmin(admin.ModelAdmin):
    list_display=["ride_choice","ride_price"]


admin.site.register(ride,rideAdmin)
admin.site.register(ridePrice,ridePriceAdmin)
admin.site.register(passengars,passengarAdmin)
admin.site.register(riders,riderAdmin)
admin.site.register(locations,locationAdmin)