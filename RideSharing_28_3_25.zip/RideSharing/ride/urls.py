from django.urls import path,include
from .import views

app_name="ride"

urlpatterns = [
    path('', views.index,name="index"),
    path('login_view/', views.login_view,name="login_view"),
    path('log_out/', views.log_out,name="log_out"),
    path('rider_view/', views.rider_view,name="rider_view"),
    path('book_ride/', views.book_ride,name="book_ride"),
    path('register', views.register,name="register"),
    path('success', views.success,name="success"),
    path('error', views.error,name="error"),
    path('ride_update',views.ride_update,name="ride_update"),
    path('get_ride_choice_price', views.get_ride_choice_price,name="get_ride_choice_price"),
    path('<str:lat1>,<str:long1>,<str:lat2>,<str:long2>', views.showroute,name="show_route"),
   
]
