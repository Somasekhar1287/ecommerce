from django.shortcuts import render,redirect
from .forms import RegisterForm
import json
from django.urls import reverse
from django.contrib.auth import logout
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.models import User
from .models import riders,passengars,ridePrice,ride
import folium
from django.http import JsonResponse,HttpResponse
from . import get_route
import requests
from .forms import RiderForm
from datetime import datetime

import random
# Create your views here.
def index(request):
    if "username" in request.session:
        username=request.session["username"]
    else:
        username=""

    if "is_user_logged" in request.session:
        is_user_logged=request.session["is_user_logged"]
    else:
        is_user_logged=""
    
    context={
        "username":username,
        "is_user_logged":is_user_logged
    }
    return render(request,"ride/index.html",context)



def register(request):
    if request.method=="POST":
        form=RegisterForm(request.POST)
        print(request.POST["user_type"])
        if form.is_valid():
            if(request.POST["user_type"])=="rider":
                is_staff=True
            else:
                is_staff=False
            print(is_staff)
            form.save(is_staff)
            return redirect("ride:login_view")
    else:
        form = RegisterForm()
        return render(request,"ride/register.html",{"form":form})


def login_view(request):
    if request.method=="POST":
        form=AuthenticationForm(data=request.POST)
        print(request.POST["username"])
        try:
            user = User.objects.get(username=request.POST["username"])
        except User.DoesNotExist:
    # Handle the case where the user does not exist
            print("User not found")
            form=AuthenticationForm()
            return render(request,"ride/login.html",{"form":form, "msg":"Username doesnot exist"})
        else:
    # Check if the user is active
            if user.is_active:
                if form.is_valid():
                    if user.is_staff:
                        request.session["is_rider_logged"]=True
                        request.session["rider"]=form.cleaned_data["username"]
                        request.session["username"]=form.cleaned_data["username"]
                        user = authenticate(request, username=form.cleaned_data["username"], password=form.cleaned_data["password"])
                        return redirect("ride:rider_view")
                    else:
                        request.session["is_user_logged"]=True
                        request.session["username"]=form.cleaned_data["username"]
                        user = authenticate(request, username=form.cleaned_data["username"], password=form.cleaned_data["password"])
                        return redirect("ride:index")
                print("User is active")
            else:
                print("User is not active")
                form=AuthenticationForm()
                return render(request,"ride/login.html",{"form":form, "msg":"Admin approval Pending"})  
            

    else:
        form=AuthenticationForm()
        return render(request,"ride/login.html",{"form":form})

def rider_view(request):
    if "is_rider_logged" in request.session and "rider" in request.session:
        log_user=request.session["rider"]
        user_id=User.objects.values_list('id').get(username=log_user)
        if riders.objects.filter(rider=user_id).all().count()>0:
            rides_avail=ride.objects.filter(status="requested").all()
            print(riders.objects.filter(rider=user_id).all().count())
            riders_view=riders.objects.filter(rider=user_id).all()
            context={
            "msg":"hello",
            "riders":riders_view,
            "rides":rides_avail,
            "log_user":user_id[0]
            }
            return render(request,"ride/rider.html",context)
            print(log_user)
        else:
            if request.method=="POST":
                form=RiderForm(request.POST)
                if form.is_valid:
                    form.save()
                    return redirect("ride:success")
            else:
                form=RiderForm()
                context={
                "msg":"hello",
                "form":form,
                "log_user":user_id[0]
                }
            return render(request,"ride/rider.html",context)
        return render(request,"ride/rider.html")
    else:
        return redirect("ride:login_view")

def showroute(request,lat1,long1,lat2,long2):
    previous_value = None
    list_of_latslangs = [ {'lat': 16.7178804, 'lon': 81.089286}, 
                  {'lat': 16.7167714, 'lon':81.0956143}, 
                  {'lat': 16.7063357, 'lon': 81.0758109},
                  {'lat': 16.7161733, 'lon': 81.1073809},
                  {'lat': 16.7058478, 'lon': 81.0883724}
                  ]
    figure = folium.Figure()
    lat1,long1,lat2,long2=float(lat1),float(long1),float(lat2),float(long2)
    route=get_route.get_route(long1,lat1,long2,lat2)
    print(request.user.username)
    m = folium.Map(location=[(route['start_point'][0]),
                                 (route['start_point'][1])], 
                       zoom_start=15)
    m.add_to(figure)
    folium.PolyLine(route['route'],weight=8,color='blue',opacity=0.9).add_to(m)
    print(route["distance"])
    print(route["distance"])
    rider_markers=riders.objects.all()
    folium.Marker(location=route['start_point'],icon=folium.Icon(icon='play', color='green')).add_to(m)
    folium.Marker(location=route['end_point'],icon=folium.Icon(icon='stop', color='red')).add_to(m)
    for rider_marker in rider_markers:
        random_latlang=random.choice(list_of_latslangs)
        if random_latlang!=previous_value:
            print(random_latlang)
            driver_loc=[random_latlang["lat"],random_latlang["lon"]]
            previous_value=random_latlang
            folium.Marker(location=driver_loc,icon=folium.Icon(color="orange",icon="motorcycle", prefix='fa',icon_color='darkpurple')).add_to(m)
    figure.render()
    
    context={'map':figure}
    
    return render(request,'ride/show_route.html',context)


def get_ride_choice_price(request):
    if request.method=="POST":
        pickup_lat=request.POST["lat1"]
        pickup_lon=request.POST["lng1"]
        dropoff_lat=request.POST["lat2"]
        dropoff_lon=request.POST["lng2"]
        loc = "{},{};{},{}".format(pickup_lon, pickup_lat, dropoff_lon, dropoff_lat)
        url = "http://router.project-osrm.org/route/v1/driving/"
        r = requests.get(url + loc) 
        if r.status_code!= 200:
            return {}
        res = r.json()
        print( res['routes'][0]['distance'])
        #lat1,lng1,lat2,lng2=float(lat1),float(lng1),float(lat2),float(lng2)
        #route=get_route.get_route(lng1,lat1,lng2,lat2)
        return JsonResponse({"distance":res['routes'][0]['distance']})


def book_ride(request):
    if "is_user_logged" in request.session:
        if request.method=="POST":
            Source=request.POST["source"]
            Source_lat=request.POST["source_lat"]
            Source_lng=request.POST["source_lng"]
            Destination=request.POST["destination"]
            Destination_lat=request.POST["destination_lat"]
            Destination_lng=request.POST["destination_lng"]
            Distance=request.POST["distance"]
            Ride_choice=request.POST["ride_choice"]
            fare_per_km=ridePrice.objects.filter(ride_choice=Ride_choice).values_list('ride_price').get()
            Fare=float(fare_per_km[0])*float(Distance)
            payment_choice=request.POST["payment_choice"]
            username=request.session["username"]
            passengar_id=User.objects.values_list('id').get(username=username)
            pass_id=passengars.objects.get(passengar=passengar_id[0])

            print(Source)
            print(passengars.objects.get(passengar=passengar_id[0]))
            ride.objects.create(
                passengar=pass_id,
                source=Source,
                source_lat=Source_lat,
                source_lng=Source_lng,
                destination=Destination,
                destination_lat=Destination_lat,
                destination_lng=Destination_lng,
                distance=Distance,
                ride_choice=Ride_choice,
                fare=Fare,
                created_on=datetime.today().strftime('%Y-%m-%d')
            )
            return redirect(reverse('ride:show_route',args=[Source_lat,Source_lng,Destination_lat,Destination_lng]))
        else:
            username=request.session["username"]
            passengar_id=User.objects.values_list('id').get(username=username)
            passengars.objects.get(passengar=passengar_id[0])
            print(passengars.objects.get(passengar=passengar_id[0]).id)
            print(request.user)
            print(User.objects.values_list('id').get(username=username))
            car_km_price=ridePrice.objects.filter(ride_choice="Car").values_list('ride_price').get()
            bike_km_price=ridePrice.objects.filter(ride_choice="Bike").values_list('ride_price').get()
            auto_km_price=ridePrice.objects.filter(ride_choice="Auto").values_list('ride_price').get()
            print(type(car_km_price))
            context={
                "car_price":car_km_price[0],
                "bike_price":bike_km_price[0],
                "auto_price":auto_km_price[0],
            }
            return render(request,"ride/book_ride.html",context)
    else:
        return redirect("ride:login_view")

def log_out(request):
    logout(request)
    return redirect("ride:login_view")


def success(request):
    return render(request,"ride/success.html")

def error(request):
    return render(request,"ride/error.html")

def ride_update(request):
    if request.method=="POST":
        ride_id=request.POST["ride_id"]
        user_id=request.POST["driver_id"]
        rider=riders.objects.filter(rider=user_id).get()
        print(rider)
        ride_updated=ride.objects.filter(id=ride_id).update(status="accepted",driver=rider)
        #ride_updated.save()
        return JsonResponse({"Msg":ride_updated})
    