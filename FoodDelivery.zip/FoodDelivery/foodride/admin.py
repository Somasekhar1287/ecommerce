from django.contrib import admin
from django.utils.html import format_html
from .models import category,Restaurant,foodItem,customer,Cart,CartItem,order,orderItem
from django.core.exceptions import ObjectDoesNotExist

# Register your models here.
class categoryAdmin(admin.ModelAdmin):
    def image(self, obj):  # receives the instance as an argument
        return format_html('<img src="{}" style="max-width:150px; max-height:150px"/>'.format(obj.category_image.url))
    
    list_display=["category_name","image","category_desc"]

class restaurantAdmin(admin.ModelAdmin):
    def res_image(self, obj):  # receives the instance as an argument
        return format_html('<img src="{}" style="max-width:150px; max-height:150px"/>'.format(obj.image.url))
    
    list_display=["name","res_image","address","latitude","longitude","contact"]

    
class foodItemAdmin(admin.ModelAdmin):
    def image(self, obj):  # receives the instance as an argument
        return format_html('<img src="{}" style="max-width:150px; max-height:150px"/>'.format(obj.item_image.url))
    
    list_display=["name","image","price","description","restaurant","food_category","item_type"]


class customerAdmin(admin.ModelAdmin):
    list_display=["user","address","phone","latitude","longitude"]

class cartAdmin(admin.ModelAdmin):
    list_display=["customer","created_at"]

class cartItemAdmin(admin.ModelAdmin):
    list_display=["cart","product","quantity"]

class orderAdmin(admin.ModelAdmin):
    list_display=["order_id","order_date","customer","restaurant","total_price","status"]

class orderItemAdmin(admin.ModelAdmin):
    list_display=["order","food_item","quantity","price"]


admin.site.register(category,categoryAdmin)
admin.site.register(Restaurant,restaurantAdmin)
admin.site.register(foodItem,foodItemAdmin)
admin.site.register(customer,customerAdmin)
admin.site.register(Cart,cartAdmin)
admin.site.register(CartItem,cartItemAdmin)
admin.site.register(order,orderAdmin)
admin.site.register(orderItem,orderItemAdmin)