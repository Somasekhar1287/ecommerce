from django.urls import path,include
from . import views

app_name="foodride"
urlpatterns = [
    path('', views.index,name="index"),
    path('items/<str:cat_name>,<str:restaurant>', views.show_restaurant_category_items,name="show_restaurant_category_items"),
    path('restaurants/<str:cat_name>', views.show_category_restaurants,name="show_category_restaurants"),
    path('myorders/track/<str:lat1>,<str:long1>,<str:lat2>,<str:long2>', views.show_route,name="show_route"),
    path('get_items',views.get_items,name="get_items"),
    path('add_cart',views.add_cart,name="add_cart"),
    path('checkout',views.checkout,name="checkout"),
    path('add_order',views.add_order,name="add_order"),
    path("login",views.login_view,name="login_view"),
    path("logout",views.log_out,name="log_out"),
    path("register",views.register_view,name="register_view"),
    path("customer",views.customer_details,name="customer_details"),
    path("success",views.success,name="success"),
    
]
