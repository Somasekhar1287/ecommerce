var items=document.getElementsByClassName("item");

for(i=0;i<items.length;i++){
    items[i].addEventListener("click",function(){
        console.log(this.getAttribute("data-id"));
        var cat_name=this.getAttribute("data-id");
       
       
        let newUrl='/foodride/restaurants/'+cat_name;
        window.location.href=newUrl;
        /*
        $.ajax({
            type:"POST",
            url:"{% url 'foodride:show_items' %}",
            dataType:"html",

            data:{"cat_name":cat_name,'csrfmiddlewaretoken': '{{ csrf_token }}',},
            success:function(response){
              console.log(typeof response);
              
                //console.log(typeof(distance_array));
            },
            error:function(data){
                console.log(data);
            },

        });*/
    });
}
