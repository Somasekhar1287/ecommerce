from django.db import models
from django.contrib.auth.models import User
# Create your models here.
ride_choices=(
    ("Car","Car"),
    ("Bike","Bike"),
    ("Auto","Auto"),
)



STATUS_CHOICES = (
        ('requested', 'Requested'),
        ('accepted', 'Accepted'),
        ('ongoing', 'Ongoing'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    )
class passengars(models.Model):
    class Meta:
        verbose_name_plural = 'passengars'

    passengar=models.OneToOneField(User, on_delete=models.CASCADE)
    phone=models.CharField(max_length=15)
    email=models.CharField(max_length=200)
    created_on=models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.passengar.username} {self.phone} {self.email} "


class locations(models.Model):
    class Meta:
        verbose_name_plural = 'locations'
    passengar=models.OneToOneField(User, on_delete=models.CASCADE)
    location_name=models.CharField(max_length=30,default=None,blank=True)
    location_lat=models.FloatField()
    location_lng=models.FloatField()
    def __str__(self):
        return f"{self.passengar} {self.location}  "

class riders(models.Model):
    class Meta:
        verbose_name_plural = 'riders'

    rider=models.OneToOneField(User, on_delete=models.CASCADE,limit_choices_to={'is_staff': True,'is_superuser': False})
    phone=models.CharField(max_length=15)
    vehicle_type=models.CharField(max_length=20,choices=ride_choices,default="Bike",null=False,blank=False)
    brand=models.CharField(max_length=50,null=True,blank=True)
    bike_model=models.CharField(max_length=50,null=True,blank=True)
    registration_number=models.CharField(max_length=20,null=True,blank=True, unique=True)
    capacity = models.IntegerField(default=1)
    created_on=models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"{self.rider} {self.phone} {self.brand} {self.bike_model} {self.vehicle_type} {self.registration_number} "


class ride(models.Model):
    passengar=models.ForeignKey(passengars, on_delete=models.CASCADE)
    driver=models.ForeignKey(riders, on_delete=models.SET_NULL, null=True, blank=True, related_name="driven_rides")
    source=models.TextField(null=True)
    source_lat=models.FloatField(default=0.0)
    source_lng=models.FloatField(default=0.0)
    destination=models.TextField(null=True)
    destination_lat=models.FloatField(default=0.0)
    destination_lng=models.FloatField(default=0.0)
    distance=models.FloatField(default=0.0)
    ride_choice=models.CharField(choices=ride_choices,max_length=5)
    fare=models.FloatField(default=0.0)
    status=models.CharField(max_length=20, choices=STATUS_CHOICES, default='requested')
    created_on=models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"{self.passengar} {self.driver} {self.source} {self.destination} {self.ride_choice} {self.fare} {self.status}"


class ridePrice(models.Model):
    ride_choice=models.CharField(choices=ride_choices,max_length=5)
    ride_price=models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Ride Price/KM")
    def __str__(self):
        return f"{self.ride_choice} {self.ride_price}"


class Payment(models.Model):
    ride = models.OneToOneField(ride, on_delete=models.CASCADE, related_name="payment",default=None)
    rider = models.ForeignKey(User, on_delete=models.CASCADE, related_name="payments",default=None)
    amount = models.FloatField(default=0.0)
    payment_method = models.CharField(max_length=20, choices=[("cash", "Cash"), ("card", "Card"), ("upi", "UPI")],default=None)
    payment_status = models.CharField(max_length=20, choices=[("pending", "Pending"), ("completed", "Completed")], default="pending")
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Payment {self.id} - {self.amount}"