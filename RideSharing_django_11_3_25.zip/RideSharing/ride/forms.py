from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import riders

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

    def save(self,is_staff,commit=True):
        user = super().save(commit=False)
        user.is_active = False  # Prevent login until approved
        user.is_staff=is_staff
        if commit:
            user.save()
        return user

class RiderForm(forms.ModelForm):
    class Meta:
        model=riders
        fields=["rider","phone","vehicle_type","brand","bike_model","registration_number","capacity"]