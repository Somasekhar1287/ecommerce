console.log("hello");

$(".sub-menu").on("mouseover",function(){
    if($(".drop-icon").hasClass("fa-angle-right"))
        {
            $(".drop-icon").addClass("fa-angle-down").removeClass("fa-angle-left");
        }
    $(this).children(".dropdown").css({"display":"block"});
});

$(".sub-menu").on("mouseleave",function(){
    if($(".drop-icon").hasClass("fa-angle-down")){
        $(".drop-icon").addClass("fa-angle-right").removeClass("fa-angle-down");
    }
    $(this).children(".dropdown").css({"display":"none"});
});